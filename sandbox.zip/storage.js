// Menetapkan cookie
document.cookie = "name=John";

// Mendapatkan cookie
var name = document.cookie.split("=")[1];
console.log("Nama dari cookie: " + name);

// Menghapus cookie
document.cookie = "name=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
console.log("Cookie 'name' telah dihapus");

// Menyimpan informasi secara lokal
localStorage.setItem("gender", "male");
localStorage.setItem("email", "john@example.com");
console.log("Informasi 'gender' dan 'email' telah disimpan ke localStorage");

// Mendapatkan informasi dari penyimpanan lokal
var gender = localStorage.getItem("gender");
var email = localStorage.getItem("email");
console.log("Jenis kelamin dari localStorage: " + gender);
console.log("Email dari localStorage: " + email);

// Menghapus informasi dari penyimpanan lokal
localStorage.removeItem("gender");
localStorage.removeItem("email");
console.log("Informasi 'gender' dan 'email' telah dihapus dari localStorage");
