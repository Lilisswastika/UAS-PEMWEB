<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['fname'];
  $agree = $_POST['myCheck'];
  $gender = $_POST['gender'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  echo "Nama: " . $name . "<br>";
  echo "Setuju: " . ($agree ? "Ya" : "Tidak") . "<br>";
  echo "Jenis Kelamin: " . ($gender == "male" ? "Laki-laki" : "Perempuan") . "<br>";
  echo "Email: " . $email . "<br>";
  echo "Password: " . $password . "<br>";
}
?>