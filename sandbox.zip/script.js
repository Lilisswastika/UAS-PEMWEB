// Misalkan ini adalah data pengguna yang Anda miliki
var users = [
  { name: "Farhan", gender: "Laki-laki", email: "farhan@gmail.com" },
  { name: "Lilis", gender: "Perempuan", email: "lilis@gmail.com" },
  { name: "Tiara", gender: "Perempuan", email: "tiara@gmail.com" },
  // dan seterusnya...
];

var tbody = document.querySelector("#myTable tbody");

users.forEach(function (user) {
  var row = document.createElement("tr");
  var nameCell = document.createElement("td");
  var genderCell = document.createElement("td");
  var emailCell = document.createElement("td");

  nameCell.textContent = user.name;
  genderCell.textContent = user.gender;
  emailCell.textContent = user.email;

  row.appendChild(nameCell);
  row.appendChild(genderCell);
  row.appendChild(emailCell);

  tbody.appendChild(row);
});
