# PHP Starter

Quickly get started with [PHP](https://www.php.net/) using this starter! PHP is a popular general-purpose scripting language that is especially suited to web development.

This starter starts a PHP web server on [localhost:8080](http://localhost:8080).
