<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="styles.css">
</head>
<body>

<h2>Formulir Pendaftaran</h2>

<form id="myForm" action="submit.php" method="post">
  Nama Lengkap: <input type="text" id="fname" name="fname"><br>
  <input type="checkbox" id="myCheck" name="myCheck"> Saya setuju dengan syarat dan ketentuan<br>
  Pilih Jenis Kelamin: 
  <input type="radio" id="male" name="gender" value="male">
  <label for="male">Laki-laki</label><br>
  <input type="radio" id="female" name="gender" value="female">
  <label for="female">Perempuan</label><br>
  Alamat Email: <input type="text" id="email" name="email"><br>
  Kata Sandi: <input type="password" id="password" name="password"><br>
  <input type="submit" value="Daftar">
</form>

<h2>Data Pengguna</h2>

<table id="myTable">
  <!-- Data pengguna akan dimuat di sini -->
</table>
<table id="myTable">
  <thead>
    <tr>
      <th>Nama</th>
      <th>Jenis Kelamin</th>
      <th>Email</th>
    </tr>
  </thead>
  <tbody>
    <!-- Data pengguna akan dimuat di sini -->
  </tbody>
</table>

<script src="script.js"></script>

</body>
</html>