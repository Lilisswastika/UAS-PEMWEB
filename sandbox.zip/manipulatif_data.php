<?php
include 'db_config.php';

$sql = "INSERT INTO Users (name, gender, email, password) VALUES ('John', 'male', 'john@example.com', 'john123')";
$conn->query($sql);

$sql = "SELECT * FROM Users";
$result = $conn->query($sql);

$sql = "UPDATE Users SET email='john.doe@example.com' WHERE name='John'";
$conn->query($sql);

$conn->close();
?>